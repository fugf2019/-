from django.apps import AppConfig


class TopicConfig(AppConfig):
    name = 'topic'
